*************************************************
*** Laboratoire 2, cours algorithme numerique ***
***                29.04.2015                 ***
*************************************************

 But :
  Developper un programme presentant une des deux
  methodes : Cramer ou Gauss.

  Nous avons choisi de developper la technique de
  Gauss et des tester la rapidite du programme
  avec la matrice fournie de 200x200.

 Participants :
  Divernois Margaux
      <margaux.divernois@he-arc.ch>
  Bitter Lukas
      <lukas.bitter@he-arc.ch>
  Da Mota Marques Fabio
      <FabioManuel.DaMotaMarques@he-arc.ch>
  Visinand Steve
      <steve.visinand@he-arc.ch>


*************************************************
